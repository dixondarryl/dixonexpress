document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const message = document.getElementById('message').value.trim();

    if (!name || !message) {
        alert('Merci de remplir tous les champs !');
        return;
    }

    const phone = '22960722094'; // Ton numéro WhatsApp, sans le + au début

    const text = encodeURIComponent(`Bonjour, je suis ${name}.\n${message}`);

    const url = `https://wa.me/${phone}?text=${text}`;

    window.open(url, '_blank');
});


