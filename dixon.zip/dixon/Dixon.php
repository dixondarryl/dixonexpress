<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = intval($_POST['rating']);
    $comment = strip_tags(trim($_POST['comment']));

    if ($rating >=1 && $rating <=5 && !empty($comment)) {
        $line = $rating . "|" . $comment . "\n";
        file_put_contents("reviews.txt", $line, FILE_APPEND | LOCK_EX);
    }
    // Redirige vers la page d’accueil pour éviter le renvoi du formulaire
    header("Location: Dixon.html");
    exit();
}
?>
